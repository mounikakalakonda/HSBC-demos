package com.trg.data;

public class B {

}
