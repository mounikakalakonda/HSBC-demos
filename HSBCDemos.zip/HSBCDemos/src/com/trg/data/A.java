package com.trg.data;

public class A {
	
	public A() {
		System.out.println("In A's cons()");
	}

}
