package com.hsbc;

public class Demo1 {
		
	public static void main(String[] args) {
	  /* int a = 10;
	   
	   Integer iobj = new Integer(a);
	   
	   int b = Integer.valueOf(iobj);
	   
	   char ch = 'a';
	   Character cobj = new Character(ch);*/
	   
	   
	   //prior to JDK 1.5, Java 5
	   // autoboxing, unboxing
	   
	   int i = 100;
	   Integer iobj = i;  //Boxes up into an obj!!  -- autoboxing
	   
	   int j = iobj;  //unboxing , obj converts back into a primitive
	  
	   
	}
}
