package com.hsbc.collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;



public class LinkedListDemo {

	public static void main(String[] args) {
		
		
		/*List<Emp> emplist = new LinkedList<>();
		emplist.add(new Emp(1,"aaa", 80000));
		emplist.add(new Emp(2,"bbb", 70000));
		emplist.add(new Emp(3,"ccc", 40000));
		emplist.add(new Emp(4,"ddd", 90000));
		emplist.add(new Emp(5,"eee", 30000));
		
		
		
		/*for(Emp emp : emplist) {
			if(emp.getSal() < 50000)
				emplist.remove(emp);
		}*/
		
		/*for(int i = 0 ; i < emplist.size() ; i++) {
			Emp emp = emplist.get(i);
			if(emp.getSal() < 50000)
				emplist.remove(i);
		}
		*/
		
		/*Iterator<Emp> it = emplist.iterator();
		while(it.hasNext()) {
			Emp emp = it.next();
			if(emp.getSal() < 50000)
				it.remove();
		}*/
		

		
		List<Integer> list = new ArrayList<>();

		list.add(500);
		list.add(200);
		list.add(100);
		list.add(400);
		
		List<Integer> l1 = Arrays.asList(100,200,300,400,500);
		
		for(Integer i : l1)
			System.out.println(i);
     
		List<String> l2 = Arrays.asList("aaaa","bbb","ccc","dddd");
			for(String s : l2)
				System.out.println(s);
		
        List<Emp> l3 = Arrays.asList(new Emp(1,"aa",10), new Emp(2,"bbb",10), new Emp(3,"ccc",10));
        for(Emp e : l3)
        	System.out.println(e);
		

	}

}










