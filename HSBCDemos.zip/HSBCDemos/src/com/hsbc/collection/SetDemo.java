package com.hsbc.collection;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {
	
	public static void main(String[] args) {
		
		Set<Emp> emplist = new TreeSet<>(new EmpComparator());
		
		emplist.add(new Emp(3,"ggg", 40000));
		emplist.add(new Emp(1,"zzzz", 80000));
		emplist.add(new Emp(2,"ttt", 70000));
		emplist.add(new Emp(5,"aaa", 30000));
		emplist.add(new Emp(4,"ddd", 90000));
		
		
		for(Emp e : emplist)
			System.out.println(e);
		
		
		
		
		TreeSet<String> set1 = new TreeSet<>();
		set1.add("hhhhh");
		set1.add("aaa");
		set1.add("ppp");
		set1.add("dddd");
		set1.add("gggg");
		set1.add("nnn");
		set1.add("qqqq");
		set1.add("llll");
		
		System.out.println(set1);
		System.out.println(set1.descendingSet());
		
		
		
		/*Set<Integer> set = new TreeSet<>();
	
		set.add(800);
		set.add(700);
		set.add(300);
		set.add(200);
		set.add(500);
		set.add(100);
		set.add(600);
		
		System.out.println(set);*/
		
		
		
		
	}

}
