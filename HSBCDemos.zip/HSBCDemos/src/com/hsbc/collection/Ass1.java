package com.hsbc.collection;

public class Ass1 {
	
    /*public void setNames() {}
   setName(String str) {}
	public void searchName(String name) {} 
	public void searchName(int index) {}
	public void printNames( ) 
	public void removeName( String stuName ) */


}
