package com.hsbc.collection;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {

		/*Map<Integer, String> map = new HashMap<>();

		map.put(1, "Jan");
		map.put(2, "Feb");
		map.put(3, "Mar");
		map.put(4, "Apr");

		System.out.println(map);

		System.out.println(map.get(3));

		Set<Integer> keys = map.keySet();
		for (Integer key : keys)
			System.out.println(key + " : " + map.get(key));*/

		Map<String, String> users = new HashMap<>();
		
		users.put("user1", "pass1");
		users.put("user2", "pass2");
		users.put("user3", "pass3");
		users.put("user4", "pass4");
		
		//accept username, password, pls hardcode here
		

	}

}

















