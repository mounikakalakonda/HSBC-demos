package com.hsbc.collection;

class Emp {

	int id;
	String ename;
	int sal;

	public Emp(int id, String ename, int sal) {
		super();
		this.id = id;
		this.ename = ename;
		this.sal = sal;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getSal() {
		return sal;
	}

	public void setSal(int sal) {
		this.sal = sal;
	}

	@Override
	public String toString() {
		return "Emp [id=" + id + ", ename=" + ename + ", sal=" + sal + "]";
	}

	@Override
	public boolean equals(Object obj) {
		Emp emp = (Emp) obj;
		if (this.getId() == emp.getId())
			return true;
		else
			return false;
	}

	@Override
	public int hashCode() {
		return this.id;
	}

	public static void main(String[] args) {

		Emp e1 = new Emp(1, "aaa", 20000);
		Emp e2 = new Emp(1, "aaa", 20000);

		System.out.println(e1 == e2); // false
		System.out.println(e1.equals(e2)); // false

	}

}
