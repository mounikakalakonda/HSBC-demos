package com.hsbc;

import java.util.Scanner;

public class ArrayDemo1 {

	public static void main(String[] args) {
		//array of objects
		/*
		Box b1 = new Box(1,2,3);   //named objects
		Box b2 = new Box(10,20,30);
		Box b3 = new Box(11,22,33);
		*/
		
		int arr[] = new int[3];  //array of primitive
		
		Box barr[] = new Box[3];  //array of obj
		barr[0] = new Box(1,2,3);   //anonymous objects
		barr[1] = new Box(10,20,30);
		barr[2] = new Box(11,22,33);
		
		for(Box b : barr)
			b.displayDimensions();
		
	}
}
