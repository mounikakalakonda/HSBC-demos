package com.hsbc;

public class Point extends Shape{
	
	public  void draw() {
		System.out.println("Drawing a point!!");
	}
	
	
}
