package com.hsbc.intf;

public interface Brakeable {

	public void brake();
}
