package com.hsbc.intf;

public class Acceleratable {

	public void accelerate() {
		System.out.println("Accelerating the car!!");
	}
}
