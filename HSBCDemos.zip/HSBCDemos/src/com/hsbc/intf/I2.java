package com.hsbc.intf;

public interface I2 extends I1{
	public void m3();
	public void m4();
}
