package com.hsbc.intf;

public interface I1 {
	
	int i = 10;  //public, static, final
	
	public void m1();
	public void m2();
}
