package com.hsbc.intf;

public class JavaCar extends Acceleratable implements Brakeable{

	@Override
	public void brake() {
		System.out.println("Stopping the car!!");	
	}
	
	public static void main(String[] args) {
		JavaCar car = new JavaCar();
		car.accelerate();
		car.brake();
	}

}
