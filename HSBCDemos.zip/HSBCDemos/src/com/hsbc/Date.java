package com.hsbc;

public class Date {
	int dd, mm, yy;

	public int getDd() {
		return dd;
	}

	public void setDd(int dd) {
		if(dd > 0 && dd <=31)
		    this.dd = dd;
		else
			System.out.println("dd is incoorrect");
	}

	public int getMm() {
		return mm;
	}

	public void setMm(int mm) {
		this.mm = mm;
	}

	public int getYy() {
		return yy;
	}

	public void setYy(int yy) {
		this.yy = yy;
	}

	@Override
	public String toString() {
		return "Date [dd=" + dd + ", mm=" + mm + ", yy=" + yy + "]";
	}

	public Date(int dd, int mm, int yy) {
		super();
		this.dd = dd;
		this.mm = mm;
		this.yy = yy;
	}

}
