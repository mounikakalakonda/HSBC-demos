package com.hsbc;

public class HelloWorld {
	
	public static void main(String[] args) {
		System.out.println("Hello, welcome to Java");
	}
}
