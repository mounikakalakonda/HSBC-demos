package com.hsbc.inheritance;

public class WageEmp extends Emp{
	
	private int hrs, rate;
	
	public WageEmp() {
		super();
	}
	
	public WageEmp(int empid, String empname, int hrs, int rate) {
		super(empid, empname);
		this.hrs = hrs;
		this.rate = rate;
	}
	
	public  int calcSalary() {
		return hrs * rate;
	}
	
	public static void main(String[] args) {
		WageEmp we1 = new WageEmp(101, "Supriya", 20, 1500);
		we1.displayEmpDetails();
		System.out.println(we1.calcSalary());
		
		
		
		
	}

}






