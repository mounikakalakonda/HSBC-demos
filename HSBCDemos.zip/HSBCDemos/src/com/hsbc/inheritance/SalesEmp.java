package com.hsbc.inheritance;

public class SalesEmp extends WageEmp{
	
	int comm;
	
	public SalesEmp(int id, String name, int hrs, int rate, int comm) {
		super(id, name, hrs, rate);
		this.comm = comm;
	}
	

	public int calcSalary() {
		return super.calcSalary() + comm;
	}
	
	
	public static void main(String[] args) {
		SalesEmp se1 = new SalesEmp(102, "Shrashti", 10, 1200, 4000);
		System.out.println(se1.calcSalary());
		se1.displayEmpDetails();
		
		
	}

}
