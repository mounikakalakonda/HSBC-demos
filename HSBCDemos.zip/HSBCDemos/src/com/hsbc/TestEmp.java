package com.hsbc;

import com.hsbc.inheritance.Emp;

public class TestEmp {
	public static void main(String[] args) {
		Emp e1 = new Emp(101,"aaa");
		e1.displayEmpDetails();
		
		
	}

}
