package com.hsbc;

import java.util.Arrays;
import java.util.Scanner;

public class ArrayDemo {
	
	public static void main(String[] args) {
		/*int arr[] = new int[5];
		arr[0] = 10;
		arr[1] = 20;
		arr[2] = 30;
		arr[3] = 40;
		arr[4] = 50;
		
		int arr1[] = {1,2,3,4,5}; 
		
		for(int i=0; i < arr1.length ; i++)  //tradional for loop
			System.out.println(arr1[i]);
		
		//Java 5 - enhanced for loop
		for(int ele : arr1)
			System.out.println(ele);
		
		float[] farr = new float[3];
		float[] farr1 = {1.2f, 3.3f, 5.5f};
		
		for(float f : farr1)
			System.out.println(f);
		
		char carr[] = {'a','b','c','d'};
		for(char ch : carr)
			System.out.println(ch);*/
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter  no of students");
		int size = sc.nextInt();
		
		String names[] = new String[size];
		for(int i=0; i < size ; i++)
			names[i] = sc.next();
		
		System.out.println(Arrays.toString(names));
		
	}

}









