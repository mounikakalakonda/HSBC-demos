package com.hsbc;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class EmpReader {
	
	public static void main(String[] args) throws IOException {
		
		FileReader fr = new FileReader("emp.txt");
		BufferedReader br = new BufferedReader(fr);
		Emp[] earr = new Emp[4];
		int i = 0;
		
		String line;
		
		
		while ((line = br.readLine()) !=  null) {
			String[] arr = line.split(":");
			Emp e1 = new Emp(Integer.parseInt(arr[0]), arr[1],Integer.parseInt(arr[2]));
			earr[i] = e1;
			i++;
		}
		
		for(Emp e : earr)
			System.out.println(e);
	}

}
