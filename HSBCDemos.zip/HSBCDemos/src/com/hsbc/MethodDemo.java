package com.hsbc;

public class MethodDemo {

	public void greet(){
		System.out.println("Hello World");
	}
	
	public void greetUser(String username){
		System.out.println("Hello " + username);
	}
	
	public int add(int a, int b) {
		return a + b;
	}
	
	public static void main(String[] args) {
		MethodDemo md = new MethodDemo();
		md.greet();
		md.greetUser("Rishita");
		System.out.println(md.add(100, 200));
		
	}
}
