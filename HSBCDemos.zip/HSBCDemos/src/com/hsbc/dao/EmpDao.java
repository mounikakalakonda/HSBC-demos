package com.hsbc.dao;

import java.util.Arrays;

import com.hsbc.model.Emp;

public class EmpDao  implements EmpDaoIntf{
	
	Emp[] emparr = new Emp[6];  //data store
	
	public EmpDao() {
		emparr[0] = new Emp(1,"aaa", 20000);
		emparr[1] = new Emp(2,"bbb", 20000);
		emparr[2] = new Emp(3,"ccc", 20000);
		emparr[3] = new Emp(4,"ddd", 20000);
		emparr[4] = new Emp(5,"eee", 20000);
	}

	@Override
	public void displayAll() {
		System.out.println(Arrays.toString(emparr));	
	}

	@Override
	public Emp getEmpById(int id) {
		/*for(Emp e : emparr) {
			if(e.getEmpId() == id)
				return e;
				
		}*/
		return null;
	}

	@Override
	public Emp[] getEmpWithSalGreaterThan(int amount) {
		return null;
	}

	@Override
	public void addEmp(Emp emp) {
		emparr[5] = emp;		
	}

	@Override
	public void deleteEmpWithId(int id) {
		// TODO Auto-generated method stub
		
	}
	
	

}
