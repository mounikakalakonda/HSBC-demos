package com.hsbc.dao;

import com.hsbc.model.Emp;

public interface EmpDaoIntf {
	
	public void displayAll();
	public Emp getEmpById(int id);
	public Emp[] getEmpWithSalGreaterThan(int amount);
	public void addEmp(Emp emp);
	public void deleteEmpWithId(int id);
	
	
	//CRUD - Create Read Update Delete

}
