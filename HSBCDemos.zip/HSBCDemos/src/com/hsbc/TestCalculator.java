package com.hsbc;

public class TestCalculator {

	public static void main(String[] args) {
        
		System.out.println(Calculator.add(100, 200));
		System.out.println(Calculator.add("Pavleen", "Kaur"));
		System.out.println(Calculator.add(10, 20, 30));
		
		
		System.out.println(Math.abs(-100));
		System.out.println(Math.pow(2, 5));
		
	}
}
