package com.hsbc;

public class Empl {
	int empId;
	String empName;
	int sal;

	public Empl() {
		this("unknown");
	}

	public Empl(String empName, int sal) {
		this.empName = empName;
		this.sal = sal;
	}

	public Empl(String empName) {
		this(empName, 80000);
	}

	@Override
	public String toString() {
		return "Empl [empId=" + empId + ", empName=" + empName + ", sal=" + sal + "]";
	}

	public static void main(String[] args) {
		Empl e1 = new Empl();
		Empl e2 = new Empl("Vandana");
		Empl e3 = new Empl("Pavleen", 60000);
		System.out.println(e1);
		System.out.println(e2);
		System.out.println(e3);

	}

}
