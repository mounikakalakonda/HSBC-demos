package com.hsbc;

public class Calculator {
	
	public static int add(int a, int b) {
		return a + b;
	}
	
	public static String add(String a, String b) {
		return a + b;
	}
	
	public static int add(int a, int b, int c) {
		return a + b + c;
	}
	

}






