package com.hsbc.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class OOSDemo {
	
	public static void main(String[] args) {
		Student stud1 = new Student(100,"Mounika");
		
		try {
			FileOutputStream fos = new FileOutputStream("s1");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(stud1);
			oos.close();
			fos.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			FileInputStream fis = new FileInputStream("s1");
			ObjectInputStream ois = new ObjectInputStream(fis);
			Student stud2 = (Student)ois.readObject();
			System.out.println(stud2);
			
			ois.close();
			fis.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}
