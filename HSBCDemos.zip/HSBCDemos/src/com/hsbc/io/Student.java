package com.hsbc.io;

import java.io.Serializable;

public class Student implements Serializable{
	int rollno;
	String sname;
	
	public Student(int rollno, String sname) {
		super();
		this.rollno = rollno;
		this.sname = sname;
	}

	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", sname=" + sname + "]";
	}

}
