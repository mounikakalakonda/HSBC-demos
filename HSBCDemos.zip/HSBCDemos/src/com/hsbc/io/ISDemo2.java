package com.hsbc.io;

import java.io.FileInputStream;
import java.io.IOException;

public class ISDemo2 {

	public static void main(String[] args) throws IOException {

		FileInputStream fis = new FileInputStream("students.txt");
		
		int size = fis.available();
		
		byte[] barr = new byte[size];
		
		fis.read(barr);
		
		String str = new String(barr);
		System.out.println(str);
		
	}

}







