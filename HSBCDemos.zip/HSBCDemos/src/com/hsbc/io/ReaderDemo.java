package com.hsbc.io;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReaderDemo {
	
	public static void main(String[] args) throws IOException {
		
				
		FileReader reader = new FileReader("students.txt");
		BufferedReader br = new BufferedReader(reader);
		String line = null;
		
		while ((line = br.readLine()) !=  null) {
			System.out.println(line);
		}
		reader.close();
		br.close();
		
		FileWriter fw = new FileWriter("output.txt");
		fw.write("Some string");
		fw.close();
		
	}

}
