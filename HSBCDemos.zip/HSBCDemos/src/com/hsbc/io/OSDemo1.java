package com.hsbc.io;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class OSDemo1 {

	public static void main(String[] args) throws IOException {
		
		String str = "Hello coders, welcoem to file output example";
		
		byte[] barr = str.getBytes();
		
		
		FileOutputStream  fos = new FileOutputStream("sample.txt");
		fos.write(barr);
		
	}
}
