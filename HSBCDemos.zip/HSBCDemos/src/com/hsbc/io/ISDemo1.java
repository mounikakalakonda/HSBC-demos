package com.hsbc.io;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class ISDemo1 {

	public static void main(String[] args) throws IOException {

		FileInputStream fis = new FileInputStream("students.txt");
		BufferedInputStream bis = new BufferedInputStream(fis);
		
		StringBuilder sb = new StringBuilder();

		int data = bis.read();
		while (data != -1) {
			sb.append((char) data);
			data = bis.read();
		}
		
		fis.close();
		
		String str = new String(sb);
		System.out.println(str);

	}

}
