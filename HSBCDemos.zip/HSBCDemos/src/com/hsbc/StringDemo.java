package com.hsbc;

import java.util.Arrays;

public class StringDemo {
	
	public static void main(String[] args) {
		String s1 = "Hello World";
		
		System.out.println(s1.length());  //11
		System.out.println(s1.charAt(0)); //H
		System.out.println(s1.indexOf("o"));  //4
		System.out.println(s1.indexOf("orl")); //7
		System.out.println(s1.toUpperCase());
		System.out.println(s1.toLowerCase());
		
		String s2 = "Gauutami,Manushree,Supriya,Priyanka,Amitesh";
		
		String[] arr = s2.split(",");
		System.out.println(Arrays.toString(arr));
		
		String joinedStr = String.join("|","aaaa","bbb","cccc","ddd");
		System.out.println(joinedStr);
	}

}
