package com.hsbc.EmpOp.test;

import com.hsbc.dao.EmpDao;
import com.hsbc.dao.EmpDaoIntf;
import com.hsbc.model.Emp;

public class EmpClientApp {
	
	public static void main(String[] args) {
		EmpDaoIntf empop = new EmpDao();
		
		empop.displayAll();
		//accept emp details from teh user!
		
		Emp e = new Emp(102,"zzz", 50000);
		empop.addEmp(e);
		
		empop.displayAll();
		
		//accept from user if of emp whose details you want to delet
		
		//empop.deleteEmpWithId(id);
	}

}
