package com.hsbc;

public class Circle extends Point{

	public  void draw() {
		System.out.println("Drawing a Circle!!");
	}
	
	public static void main(String[] args) {
		Shape s1 = new Point();
		s1.draw();
		
		Shape s2 = new Circle();
		s2.draw();
		
		
	}
}
