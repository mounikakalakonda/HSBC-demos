package com.hsbc;

/*
 * Author: Shrilata
 * date : 
 * purpose:
 */
public class Box {
	
	private int length, width, height;  
	
	public Box() {	}  //no arg cons

	public Box(int length, int width, int height) {
		this.length = length;
		this.width = width;
		this.height = height;
	}

	public void displayDimensions() {
		System.out.println( "Box [length=" + length + ", width=" + width + ", height=" + height + "]");
	}

	@Override
	public String toString() {
		return "Box [length=" + length + ", width=" + width + ", height=" + height + "]";
	}

	/* purpose :    */
	public int calcVolume() {
		int volume;   
		volume = length * width * height;
		return volume;
	}
	
	
	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public static void main(String[] args) {
		Box b1 = new Box(10,5,10);
		b1.displayDimensions();
		
		Box b2 = new Box();
		b2.displayDimensions();
		
		System.out.println(b1);
		
	}
	
}
