package com.hsbc;

public class Person {

	int perId;
	String perName;
	Date dob;
	
	public Person(int perId, String perName, Date dob) {
		this.perId = perId;
		this.perName = perName;
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "Person [perId=" + perId + ", perName=" + perName + ", dob=" + dob + "]";
	}
	
	public static void main(String[] args) {
		
		Person p1 = new Person(101, "Atul", new Date(11,9,2001));
		System.out.println(p1);
	}
	
	
	
}







