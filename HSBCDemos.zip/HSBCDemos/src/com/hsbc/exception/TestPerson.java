package com.hsbc.exception;

public class TestPerson {
	public static void main(String[] args) {
		Person p1 = new Person();
		
		try {
		  p1.setPersonDetails(101, null, 22);
		}
		catch(InvalidNameException e) {
			System.out.println(e.getMessage());
		}
		System.out.println(p1);
		
	}

}
