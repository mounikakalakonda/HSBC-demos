package com.hsbc.exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Demo1 {

	public static void main(String[] args) {
		//unchecked 
		
		FileInputStream fis = null;
		
		try {
		   fis = new FileInputStream("a.txt");
		}
		catch(FileNotFoundException e) {
			//System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		
			try {
				fis.read();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		
		
				
	}
}
