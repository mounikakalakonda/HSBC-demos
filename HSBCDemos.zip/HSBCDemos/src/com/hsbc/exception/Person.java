package com.hsbc.exception;

public class Person {

	int perId;
	String pername;
	int age;

	public void setPersonDetails(int perId, String pername, int age) throws InvalidNameException{
		this.perId = perId;
		if(pername == null)
			throw new InvalidNameException("Name cannot have null in it");
		else
		this.pername = pername;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Person [perId=" + perId + ", pername=" + pername + ", age=" + age + "]";
	}

}
