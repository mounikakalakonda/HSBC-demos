package com.hsbc.factory;

import com.hsbc.model.Book;

public class BookStoreFactory {

	public static Book[] createBookStore(int size, String type) {
		Book[] arr = null;
		
		if(type.equals("array")) {
			arr = new Book[size];
		}
		return arr;
			
	}

}
