package com.hsbc.factory;

import com.hsbc.model.Book;

public interface BookStoreFactoryIntf {
	
	public Book[] createBookStore(int size, String type);

}
