package com.hsbc.dao;

import com.hsbc.model.Book;

public interface BookDaoIntf {

	//CRUD
	
	public Book getBookById(int id);
	public Book[] getAllBooks();
	//public Book[] getBooksByAuthor(String author);
	public void addBook(Book book);
	//public void deleteBookById(int id);
	
	
}
