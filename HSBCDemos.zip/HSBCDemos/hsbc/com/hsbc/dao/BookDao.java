package com.hsbc.dao;

import com.hsbc.model.Book;

public class BookDao implements BookDaoIntf {

	
	static int count = 0;
	Book[] arr = null;
	
	
	public BookDao(Book[] arr) {
		this.arr = arr;
	}

	@Override
	public Book getBookById(int id) {
		Book newBook = null;

		for (Book b : arr) {
			if (b.getBookId() == id) {
				newBook = b;
				break;
			}
		}
		return newBook;

	}

	@Override
	public Book[] getAllBooks() {
		return arr;
	}

	@Override
	public void addBook(Book book) {
		if (count < arr.length) {
			arr[count] = book;
			count++;
		} else
			System.out.println("Array is full");
	}

}




