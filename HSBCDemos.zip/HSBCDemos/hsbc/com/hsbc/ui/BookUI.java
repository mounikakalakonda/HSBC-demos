package com.hsbc.ui;


import com.hsbc.dao.BookDao;
import com.hsbc.dao.BookDaoIntf;
import com.hsbc.factory.BookStoreFactory;
import com.hsbc.model.Book;

public class BookUI {

	BookDaoIntf dao = null;
	//BookStoreFactory factory;
	Book[] arr = null;
	
	
	public BookUI() {
		
		arr = BookStoreFactory.createBookStore(5, "array");
		dao = new BookDao(arr);
	}

	public Book getBookById(int id) {
		return dao.getBookById(id);
	}

	
	public Book[] getAllBooks() {
		return dao.getAllBooks();
	}

	
	public void addBook(Book book) {
		dao.addBook(book);
		
	}

}
