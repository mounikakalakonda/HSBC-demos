package com.hsbc.test;


import com.hsbc.model.Book;
import com.hsbc.ui.BookUI;

public class BookClientApp {
	
	public static void main(String[] args) {
		
		BookUI ui = new BookUI();
		
		//Scanner
		//accept book details
		Book b1 = new Book(101,"Core Java","aaa",400);
		ui.addBook(b1);
		Book b2 = new Book(102,"Core Servlets","bbbb",400);
		ui.addBook(b2);
		Book b3 = new Book(103,"Core JSP","ccc",400);
		ui.addBook(b3);
		
		Book[] arr = ui.getAllBooks();
		for(Book b : arr)
			System.out.println(b);
		
		System.out.println("------------------------------");
		System.out.println(ui.getBookById(103));
		
		
	}

}
